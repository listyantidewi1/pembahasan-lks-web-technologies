This is the finished code for each part of the JavaScript Space Invaders Tutorial Series found at www.briankoponen.com.

If you try to open the HTML files directly in a browser, you will likely get CORS security errors. You will need to run a local webserver to get around this. An easy way to do this is to install Python (if you don't already have it) and run the following command from the folder you want to serve:

python -m SimpleHTTPServer

You can then view the page from this address: http://localhost:8000/

- Brian Koponen